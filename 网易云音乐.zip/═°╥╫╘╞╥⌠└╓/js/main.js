/**
 * Created by Administrator on 2018/10/16.
 */
window.onload=function(){
    "use strict";
    var headLi=document.querySelectorAll('header ul li');
    var headI=document.querySelectorAll('header ul li .jt');
    console.log(headLi, headI);
    for (let i = 0; i < headLi.length; i++)
    {
        headLi[i].onmouseover=function(){
            for (var j = 0; j < headI.length; j++) {
                 headI[j].classList.remove('now');
                 headLi[j].classList.remove('now');
            }
            headI[i].classList.add('now');
            headLi[i].classList.add('now');

        }

    }
    //header  hover
    var navA=document.querySelectorAll('nav ul li a');
    console.log(navA);
    for (let i = 0; i < navA.length; i++)
    {
    navA[i].onclick=function(){
        for (var j = 0; j < navA.length; j++) {
          navA[j].className="";
        }
        navA[i].className="now";
    }
    }
    var oDeng=document.getElementById('enter');
    var oDiv=document.getElementById('dl');
    oDeng.onmouseenter=function(){
        oDiv.style.display='block';
        oDiv.style.zIndex='20'
    }
    oDeng.addEventListener('mouseleave',function(){
        oDiv.onmouseenter=function(){
           oDiv.style.display='block';
                oDiv.style.zIndex='20'

        }
        oDiv.onmouseleave=function(){
            oDiv.style.display='none';
        }
    });
    var banner=document.getElementById('banner');
    var arrLi=document.querySelectorAll('.banner .img-box ul li');
    var arrImg=document.querySelectorAll('.banner .img-box img');
    var oRight=document.getElementsByClassName('right1')[0];
    var oLeft=document.getElementsByClassName('left1')[0];
    var timer=null;
    console.log(banner,arrLi,arrImg,oRight,oLeft);
    var pic=0;
    for (var i = 0; i < arrLi.length; i++) {
          arrLi[i].index=i;
          arrLi[i].onclick=function(){
          banner.style.backgroundImage='url'+"("+"img/b"+[this.index+1]+'.jpg'+")";
          for (var j = 0; j < arrLi.length; j++) {
              arrLi[j].classList.remove('now');
              arrImg[j].classList.remove('now')
          }
          arrLi[this.index].classList.add('now');
          arrImg[this.index].classList.add('now');
              pic=this.index;
      }
    }
    oRight.onclick=right;
    oLeft.onclick=left;
    function right(){
        pic++;
        for (var i = 0; i < arrImg.length; i++) {
            arrImg[i].classList.remove('now');
            arrLi[i].classList.remove('now');
        }
        if(pic==arrImg.length){
            pic=0;
        }
        arrImg[pic].classList.add('now');
        arrLi[pic].classList.add('now');
        banner.style.backgroundImage='url'+"("+"img/b"+[pic+1]+'.jpg'+")";
    }
    timer=setInterval(right,3000)
    banner.onmouseover=function(){
     clearInterval(timer);
    }
    banner.onmouseleave=function(){
        timer=setInterval(right,3000);
    }
    function left(){
        if(pic==0){
            pic=arrImg.length;
        }
        pic--;
        for (var i = 0; i < arrImg.length; i++) {
            arrImg[i].classList.remove('now');
            arrLi[i].classList.remove('now');
        }
        arrImg[pic].classList.add('now');
        arrLi[pic].classList.add('now');
        banner.style.backgroundImage='url'+"("+"img/b"+[pic+1]+'.jpg'+")";
    }
    var olook=document.getElementById('screen')
    var oLook=document.getElementById('look');
    var onewLeft=document.getElementById('ap');
    var onewRight=document.getElementById('a');
    var oul=oLook.children;
    var oulWidth=oul[0].offsetWidth;
    console.log(oLook,onewLeft, onewRight,olook,oulWidth);
    var oul1=oul[0].cloneNode(true);
    oLook.appendChild(oul1);
      var pic1=0;
      var target=0;
    console.log(oul);
    onewRight.onclick=newRight;
    onewLeft.onclick=newLeft;
    function newRight(){
        if(pic1===oul.length-1){
            oLook.style.left=0;
            pic1=0;
        }
        pic1++;
        console.log(pic1);
        target=-pic1*oulWidth;
        animate(oLook,30,target);
    }
    function newLeft(){
        if(pic1==0){
            oLook.style.left=-(oul.length-1)*oulWidth+'px'
            pic1=oul.length-1;
        }
        pic1--;
        target=-pic1*oulWidth;
        animate(oLook,30,target)
    }



}