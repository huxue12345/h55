$(function(){
	$('.menu').click(function(){
		$(".nav1").toggleClass('now')
	}
	)
})