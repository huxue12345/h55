$(function(){
	$('.banner1').load('header.html');
	$('.footer').load('footer.html')
})