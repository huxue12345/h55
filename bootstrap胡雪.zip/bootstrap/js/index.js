$(function(){
	$('.banner').load('header.html')
	$('.footer').load('footer.html')
	$('.menu').click(function(){
		$(".nav1").toggleClass('now')
	})
	$(".carousel").carousel({interval:2000})
})
