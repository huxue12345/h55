$(function(){
	$(".banner1").load('header.html');
	$('.footer').load("footer.html");
    $('.ser_btn>li').click(function(ev){
    	$(this).find('a').addClass('now');
    	$(this).siblings('li').find('a').removeClass('now')	
    	var $index=$(this).index();
    	$('.ser_cont>li').eq($index).addClass('now').siblings('li').removeClass('now')
    	  if($('.ser_cont>li').eq(0).hasClass('now')){
        	 
        	$(".cont_btn").removeClass('now')
        }else{
        	$(".cont_btn").addClass("now")
        }
        ev.preventDefault()
    })
    var index=0;
    function add(){
    	index++;
    	if(index==$('.ser_btn>li').length){
    	index=0;	
    	}
    	
    	$('.ser_cont>li').eq(index).addClass('now').siblings('li').removeClass('now')
    	  var $width=$(".cont_btn").width()
    	  if($('.ser_cont>li').eq(0).hasClass('now')){
        	 
        	$(".cont_btn").removeClass('now')
        }else{
        	$(".cont_btn").addClass('now')
        }
    	$(".ser_btn>li").eq(index).find('a').addClass('now');
    	$(".ser_btn>li").eq(index).siblings('li').find('a').removeClass('now')	
    }
   var time=null
   time=setInterval(add,2000);
   $('.service_tab').hover(function(){
   	clearInterval(time)
   },function(){
   	 time=setInterval(add,2000);
   })
	
})
