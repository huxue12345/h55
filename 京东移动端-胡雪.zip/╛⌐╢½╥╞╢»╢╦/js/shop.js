
$(function(){
	$('.shop_footer').load('footer.html')
	$(".igo").click(function(){
		$('.nav_list').toggleClass('now')
	})
	
	$('a').on("click",function(ev){
		ev.preventDefault();
		$('a').css('textDecoration',"none")
	})
	 var $sum=0;
	 var $ulwidth=0;
	$.get('json/info.json',function(str){
		console.log(str)
		var list=eval(str);
		$(list).each(function(i){
			$('<li><a href=""><img src="'
			+list[i].src+
			'" alt=""  class="img-responsive"/><p class="info_p01">'
			+list[i].tit+'</p><p class="info_p02">'
			+list[i].des+'</p></a></li>').appendTo('.ms_cont_info')	
		})
		move('.ms_cont_info>li','.ms_cont_info')
		var $wrapwidth=$('.ms_cont_wrap').width();
		$ulwidth=$('.ms_cont_info').width();
		$sum=$ulwidth-$wrapwidth
		  console.log($ulwidth,$sum)
	})//添加ul的内容
	 function move(li ,ul){
     var $width=$(li).eq(0).innerWidth();
     console.log($width)
     var $ulwidth=$(li).length*$width;
     $(ul).width($ulwidth);
   }
//   var starX=0;
     $('.ms_cont_wrap').on('touchstart',function(ev){
     	var startX=ev.touches[0].pageX;//获取点击时的横坐标	
     	$('.ms_cont_wrap').on('touchmove',function(ev){
     	var lastX=ev.touches[0].pageX;
     	var $left=parseFloat($('.ms_cont_info').css('left'))
     	var $target=$left-startX+lastX;
     	if(startX-lastX>0){//左滑
     		if($target<-$sum){
     			$target=-$sum
     		}
     	$('.ms_cont_info').css('left',$target)	
     	}else{//右滑
     		if($target>0){
     			$target=0
     		}
     	$('.ms_cont_info').css('left',$target)		
     	}	
     	})
     	$('.ms_cont_wrap').on('touchend',function(){
     		$('.ms_cont_wrap').off('touchmove')
     	})
     })
 //倒计时
 function doboul(num){
	if(num<10){
		return "0"+num
	}else{
		return num
	}
}
 var oDate =null;
var t1=null;
var onum=null;
var otim=null;
var t2=0;
var se=0;
var timc=0;
var ohou=0;
var omi=0 
function tim(){
oDate=new Date();//当前的日期
t1=oDate.getTime();
onum=oDate.getHours();
if(onum>22){
$('.font').html("22点场")
 otim=oDate.setHours(24);
 otim=oDate.setMinutes(0);
 otim=oDate.setSeconds(0);
t2=otim;//设置秒杀的时间
timc=t2-t1;//时间差
se=parseInt(timc/1000);//秒数
ohou=parseInt(se/3600);//小时
    se=se%3600;
omi=parseInt(se/60)
 se=se%60;
   if(se<0){
    	$('.h').html(doboul(00));
$('.m').html(doboul(00));
$('.s').html(doboul(00));
   }
return 
}
if(onum>16){
 $('.font').html("20点场")	
 otim=oDate.setHours(22);
 otim=oDate.setMinutes(0);
 otim=oDate.setSeconds(0);
t2=otim;//设置秒杀的时间
 timc=t2-t1;//时间差
se=parseInt(timc/1000);//秒数
ohou=parseInt(se/3600);//小时
    se=se%3600;
 omi=parseInt(se/60)//求分钟
    se=se%60;
 if(se<0){
    	$('.h').html(doboul(00));
$('.m').html(doboul(00));
$('.s').html(doboul(00));
   }
 return 
}
if(onum>10){
 $('.font').html("16点场")
 otim=oDate.setHours(16);
 otim=oDate.setMinutes(0);
 otim=oDate.setSeconds(0);
t2=otim;//设置秒杀的时间
timc=t2-t1;//时间差
se=parseInt(timc/1000);//秒数
ohou=parseInt(se/3600);//小时
    se=se%3600;
omi=parseInt(se/60)
 se=se%60;
   if(se<0){
$('.h').html(doboul(00));
$('.m').html(doboul(00));
$('.s').html(doboul(00));
   }
 return    
}
 if(onum>=0){
 $('.font').html("10点场")
 otim=oDate.setHours(10);
 otim=oDate.setMinutes(0);
 otim=oDate.setSeconds(0);
t2=otim;//设置秒杀的时间
timc=t2-t1;//时间差
se=parseInt(timc/1000);//秒数
ohou=parseInt(se/3600);//小时
    se=se%3600;
omi=parseInt(se/60)
 se=se%60;
   if(se<0){
$('.h').html(doboul(00));
$('.m').html(doboul(00));
$('.s').html(doboul(00));
   } 
    return 
}
}
setInterval(function(){
tim()
$('.h').html(doboul(ohou));
$('.m').html(doboul(omi));
$('.s').html(doboul(se));
},1000)//倒计时结束
$.ajax({'type':"Get",
   "async":false,
   "url":"json/want.json",
    "dataType":"json"}).done(function(str){
    	console.log(str);
    	var list2=eval(str);
    	$('.want_cont').html('')
    	$.each(list2,function(i){
    		$('<li><a href=""><img src="'
    		+list2[i].src+'" alt="" class="img-responsive"/><h3 class="want_cont_tit">'
    		+list2[i].tit+'</h3><p class="shop_pric">'
    		+list2[i].price+'<i class="shop_car1"></i></p></a></li>').appendTo('.want_cont')
    	})
    })


})