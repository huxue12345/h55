$(function(){
	$('.bs_footer').load('footer.html')
	$(".igo").click(function(){
		$('.nav_list').toggleClass('now')
	})
	
	$('a').on("click",function(ev){
		ev.preventDefault();
		$('a').css('textDecoration',"none")
	})
    function move(li ,ul){
     var $width=$(li).eq(0).innerWidth();
     console.log($width)
     var $ulwidth=$(li).length*$width;
     $(ul).width($ulwidth);
    }//给nav_right_cont设宽
    move('.nav_right_cont>li','.nav_right_cont');
   
     $('.nav_right').on('touchstart',function(ev){
     	var startX=ev.touches[0].pageX;
     	var $width=$('.nav_right').width();
        var $ulwidth1=$('.nav_right_cont').width();
        var $num=($ulwidth1-$width);
     	$('.nav_right').on('touchmove',function(ev){
     		var lastX=ev.touches[0].pageX;
     		var $left=parseFloat($('.nav_right_cont').css('left'))
     		var $target=0;
     		console.log(lastX);
     		if(startX-lastX>0){//左移left绝对值增大
     		  $target=$left-startX+lastX;
     		  if($target<(-$num)){
     		  	$target=-$num
     		  }
     		  $('.nav_right_cont').css('left',$target)
     		}else{//右移left绝对值减小
     			$target=$left-startX+lastX;
     			if($target>0){
     		  	$target=0
     		  }
     		   $('.nav_right_cont').css('left',$target)	
     		}
     		
     		
     	})
     	$('.nav_right').on("touchend",function(){
	  			$('.nav_right').off('touchmove')
	  		})
     })
     $('.nav_right_cont>li').click(function(){
     	$(this).find("a").addClass('now');
     	$('.nav_left>a').removeClass('now')
     	$(this).siblings('li').find('a').removeClass('now')
     })
     $('.nav_left>a').click(function(){
     	$(this).addClass('now')
     	$('.nav_right_cont>li').find("a").removeClass('now')
     })
    //导航滑动效果
    //轮播图
    move('.tab_cont>li',".tab_cont");
    var olindex=0;
    var $width1=-$('.tab_cont>li').eq(0).width()
    console.log($width1)
    function sidleleft(){
        $('.tab_cont').stop().animate({"left":$width1},600,function(){
        	$('.tab_cont>li').eq(0).appendTo($('.tab_cont'))
        	$('.tab_cont').css('left',"0")
        })
         olindex++
        if(olindex>$(".tab_btns>li").length-1){
          olindex=0
        }
       
        $(".tab_btns>li").eq(olindex).addClass('now').siblings('li').removeClass('now')
        
    }
    function sidleright(){
    	$('.tab_cont>li').eq(2).prependTo($('.tab_cont'))
    	$('.tab_cont').css('left',$width1)
        $('.tab_cont').stop().animate({"left":"0"},600,function(){ 
        })
        olindex--
         console.log(olindex)
        if(olindex<0){
        	olindex=$(".tab_btns>li").length-1
        }
        $(".tab_btns>li").eq(olindex).addClass('now').siblings('li').removeClass('now')  
    }
    var startX=0
    var time1=null
    var time=null
    time=setInterval(sidleleft,2600)
    $('.bs_tab').on('touchstart',function(ev){
    	clearInterval(time)
     startX=ev.touches[0].pageX;
    	 })
    $('.bs_tab').on('touchend',function(ev){
    	var lastX=ev.changedTouches[0].pageX;
    	    if(startX-lastX>0){//左滑
    	      
    	       sidleleft()
    	       clearTimeout(time1)
    	     time1=setTimeout(function(){
    	   	 time=setInterval(sidleleft,2600)
    	   },2000)
    	    }else if(lastX-startX>0){
    	     sidleright()
    	       clearTimeout(time1)
    	     time1=setTimeout(function(){
    	   	 time=setInterval(sidleright,2600)
    	   },2000)	
    	    }
    	 
    	})
    function dobul(num){
    	if(num<10){
    		return "0"+num;
    	}else{
    		return num;
    	}
    }
   function datetime(){
   	 var $date=new Date();//当前的日期
   	 var $t1=$date.getTime()//距离1970年的毫秒数
     var $targettime=$date.setHours(24) 
         $targettime=$date.setMinutes(0)
         $targettime=$date.setSeconds(0)
//   console.log($date,$targettime,$t1)
     var timc=$targettime-$t1//距目标的毫秒差
     var times=timc/1000//毫秒转化为秒
     var h= parseInt(times/3600)   //小时
         times=times%3600
     var m=parseInt(times/60)    ;
     var s=times%60
     $('.h').html(dobul(h));
     $('.m').html(dobul(m));
     $('.s').html(dobul(s));
   }
    setInterval(datetime,1000)
    $.ajax({
    	type:"get",
    	url:"json/skill.json",
    	async:false,
    	dataType:"json"
    }).done(function(str){
    	var list=eval(str)
    	var  str='';
        console.log(list)
    	$('.seckill_cont').html('')
    	$.each(list,function(i){
          str='<li><a href=""><img src="'+list[i].src+
          '"class="img-responsive" alt="" /> <p class="p_01 clear"><span class="s_01 fl">2人拼</span><span class="fr">￥<em>'
		         		     	+list[i].em+'</em>'+list[i].scrt+'</span></p><p class="p_02">'
		         		     	+list[i].des+'</p></a></li>'
		         		     	
		         		
    		$('.seckill_cont').append(str)
    	})
    });
     
     for(var i=0;i<3;i++){
     	console.log(i)
     	var li1=$('.seckill_cont>li').eq(i).clone(true)
     	$('.seckill_cont').append(li1)
     }//循环添加前三组li
     move('.seckill_cont>li','.seckill_cont');
     var index1=0;
     var $num1=Math.round($('.seckill_cont').width()/$('.seckill_cont_wrap').width()) 
     var target1=0 
      console.log($num1)
    function sideleft1(){
    	
     	var $width=$('.seckill_cont_wrap').width()+15
     	console.log(index1)
     	
     	if(index1>$num1-2){
     		index1=0;
     		target1=index1*$width
     		$('.seckill_cont').css({'left':target1});
     		
     	}
     	index1++
     	target1=index1*$width
     	$('.seckill_cont').stop().animate({'left':-target1},600)
        if(index1>$num1-2){
        	$('.seckill_btn>li').eq(0).addClass('now').siblings('li').removeClass('now')
        }else{
        $('.seckill_btn>li').stop().eq(index1).addClass('now').siblings('li').removeClass('now')		
        }	
     }
      function sideright1(){
     	var $width=$('.seckill_cont_wrap').width()+15
     	index1--
     	if(index1<0){
     		index1=$num1-1;
     		target1=index1*$width
     		$('.seckill_cont').css({'left':-target1});
     	}
     	target1=index1*$width
     	$('.seckill_cont').animate({'left':-target1},600)
        if(index1<0){
        	$('.seckill_btn>li').eq($num1-2).addClass('now').siblings('li').removeClass('now')
        }else{
        $('.seckill_btn>li').eq(index1).addClass('now').siblings('li').removeClass('now')		
        }	
     }
      var start1X=0
      var time2=null
      var time3=null
    time2=setInterval(sideright1,2600)
       $('.seckill_cont_wrap_out').on('touchstart',function(ev){
    	  clearInterval(time2)
          start1X=ev.touches[0].pageX;
    	 })
    $('.seckill_cont_wrap_out').on('touchend',function(ev){
    	var last1X=ev.changedTouches[0].pageX;
    	    if(start1X-last1X>0){//左滑
    	     sideleft1()
    	     clearTimeout(time3)
    	     time3=setTimeout(function(){
    	   	 time2=setInterval(sideleft1,2600)
    	   },2000)
    	    }else if(last1X-start1X>0){
    	     sideright1()
    	     clearTimeout(time3)
    	     time3=setTimeout(function(){
    	   	 time2=setInterval(sideright1,2600)
    	   },2000)	
    	    }
    	 
    	})
    //吸顶盒
    $(window).scroll(function(){
    	if($(window).scrollTop()>0){
    	$('.bs_head').css("display","none");
    	$('.bs_search_wrap').css("display","none");
    	$('.bs_nav').css({"position":"fixed","top":"0",'zIndex':"40"})
    	}else{
    	$('.bs_head').css("display","block");
    	$('.bs_search_wrap').css("display","block");
    	$('.bs_nav').css({"position":"relative"})	
    	}
    })
    //每日上新
     $.get("json/date.json",function(str){
     	var newdate=eval(str);
     	var mode=$('.bs_model>.img_middle').html();//图片
     	var mode1=$('.bs_model>.newdate_cont').html();//第一部分内容
     	var mode2=$('.bs_model>.newdate_cont01').html();//第三部分内容
     	 
     	 $('.bs_newdate_cont').html('')
//   	 console.log($('.bs_model>.newdate_cont'))
     	for(var j=0;j<newdate.length;j++){
     		var newcont01=newdate[j].newcont01
     		var newcont02=newdate[j].newcont02
     		  $('.bs_model>.newdate_cont').html('')
     		 console.log($('.bs_model>.newdate_cont').html(),mode1)
     	    $.each(newcont01,function(i){
     	     var mode3=mode1.replace('img1/5b4fff1eN058d731b.jpg_q70.jpg',newcont01[i].src1)
     	         mode3=mode3.replace('$tit$',newcont01[i].tit)
     	         mode3=mode3.replace('$hot$',newcont01[i].hot)
     	         mode3=mode3.replace('$des$',newcont01[i].des)
     	         mode3=mode3.replace('$pric1$',newcont01[i].pric1)
     	         mode3=mode3.replace('$pric2$',newcont01[i].pric2)
     	         mode3=mode3.replace('$pin$',newcont01[i].pin)
//   	         console.log(mode3)
     	      $('.bs_model>.newdate_cont').append(mode3)    
     	   })
     	   $('.bs_model>.newdate_cont01').html('')
     	  $.each(newcont02,function(i){
     	     var mode4=mode2.replace('img1/5b42e539N733a122c.jpg_q70.jpg',newcont02[i].src2)
     	         mode4=mode4.replace('$pdes$',newcont02[i].pdes)
     	         mode4=mode4.replace('$pric3$',newcont02[i].pric3)
     	         mode4=mode4.replace('$pric4$',newcont02[i].pric4)
     	      $('.bs_model>.newdate_cont01').append(mode4)    
     	   })
     	   
     	    var mode5=mode.replace('img1/b182d9c3e45f8d71.jpg_q70.jpg',newdate[j].middleimg)
     	     $('.bs_model>img_middle').html(mode5) ;
     	     var mode6=$('.bs_model').html()
//   	     console.log(mode6)
     	     $('.bs_newdate_cont').append(mode6)
     	}
     })
    	
})
