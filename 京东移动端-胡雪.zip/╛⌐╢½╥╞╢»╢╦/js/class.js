$(function(){
	$(".cl_footer").load('footer.html')
	
	
	$('.cl_hback').click(function(){
		$(window).attr("location",'index.html')
	})
	$('.cl_igore').click(function(){
	 $('.nav_list').toggleClass('now')	
	})
	var $height=$(window).height();//获取整屏的高
	var $height1=$('.cl_head').innerHeight();//获取头部的高
	var $leftheight=$height-$height1-133;//计算内容的高
	var $ulheight=$('.cl_nav').height();//获取侧边导航的内容高
	var $num=Math.round($ulheight/$leftheight) //设置滑动到的次数
	$('.cl_cont_left').height($leftheight)///设置内容的高
	$('.cl_cont_right_wrap').height($leftheight)
	var startY=0;
	var lastY=0;
	var $target=0;
	var ss=0;//left
	var start1Y=0;
	var last1Y=0;
	var $target1=0;
	var ss1=0;//right
	  $('.cl_cont_left').on('touchstart',function(ev){
	  	startY=ev.touches[0].pageY;
	  	console.log(startY)
	  	ss=parseFloat($('.cl_nav').css("top"))//开始的top值 
	  	$('.cl_cont_left').on("touchmove",function(ev){
	  		ev.preventDefault()
	  	lastY=ev.touches[0].pageY;
	  	 if(startY-lastY>0){
	  	   $target=ss-startY+lastY;
	  	     if($target<(-$ulheight+$leftheight)){
	  	 	    $target=-$ulheight+$leftheight
	  	       }
	  	     $('.cl_nav').css("top",$target+"px")
	  	 }else{
	  	 	$target=ss-startY+lastY;
	  	 	if($target>0){
	  	 		$target=0
	  	 	}
	  	 	 $('.cl_nav').css("top",$target+"px")
	  	 }
	  		
	  	})
	  		$('.cl_cont_left').on("touchend",function(){
	  			$('.cl_cont_left').off('touchmove')
	  		})
	  	
	  })//左边
    	$('.cl_cont_right_wrap').on('touchstart',function(ev){
	  	start1Y=ev.touches[0].pageY;
         var riul=$('.cl_cont_right').innerHeight()
         console.log(riul)
	  	ss1=parseFloat($('.cl_cont_right').css("top"))//开始的top值 
	  	$('.cl_cont_right_wrap').on("touchmove",function(ev){
	  	 last1Y=ev.touches[0].pageY;
	  	 if(start1Y-last1Y>0){
	  	   $target1=ss1-start1Y+last1Y;
	  	   console.log($target1)
	  	     if($target1<(-riul+$leftheight)){
	  	 	    $target1=-riul+$leftheight
	  	       }
	  	     $('.cl_cont_right').css("top",$target1+"px")
	  	 }else{
	  	 	$target1=ss1-start1Y+last1Y;
	  	 	if($target1>0){
	  	 		$target1=0
	  	 	}
	  	 	 $('.cl_cont_right').css("top",$target1+"px")
	  	 }
	  		
	  	})
	  		$('.cl_cont_right_wrap').on("touchend",function(){
	  			
	  			$('.cl_cont_right_wrap').off('touchmove')
	  		
	  		})
	  	
	  })//右边
	  

	  $('.cl_nav>li').on('click',function(ev){
	  	var $index1=$(this).index()
	  	$(this).addClass("now").siblings('li').removeClass('now');
	  	$(this).find('a').addClass('now');
	  	$(this).siblings('li').find('a').removeClass('now')
	  	$target =$index1*$(this).height();
	  	    if($(this).index()>=26){
	  	    $target=$ulheight-$leftheight
	  	    
	  	    }
            $('.cl_nav').animate({"top":-$target})
	  })
	  $.ajax({
	  "type":"get",
	  "url":"json/class.json",
	  "data":{},
	  "async":false,
	  "dataType":'json'
	  }).done(function(str){
	  	    var $list=eval(str);
	  	    var $mode=$('.model>.shop_cont').html();//商品展示内容
	  	    var $mode1=$('.model>.shop_tit').html();
	  	    var $mode2=$('.model').html();//
	  	    console.log($list)
	  	    change(0)
	  	    $('.cl_nav>li').on('click',function(ev){
	  	    var $index1=$(this).index()
	  	    change($index1)
	
	  	    ev.preventDefault()
	  	    ev.stopPropagation();	
	  	    })
	  	    function change(num){
	  	    var $list1=$list[num];	
	  	    $('.cl_cont_right').html('')
	  	    for(var i=0;i<$list1.length;i++){//循环渲染数据
	  	    var $data=$list1[i].date	
	  	    $('.model>.shop_cont').html('')
	  	    $.each($data, function(j) {
	  	      var $mode4=$mode.replace("$ss1$",$data[j].src)	
	  	      $mode4=$mode4.replace("$des$",$data[j].des)	
	  	      $('.model>.shop_cont').append($mode4)
	  	    });	//动态添加商品展示内容
	  	    var $mode5=$mode1.replace("$tit$",$list1[i].tit);  
	  	     $mode5=$mode5.replace("$tit1$",$list1[i].tit1); 
	  	     $mode5=$mode5.replace("$url1$",$list1[i].url1); 
	  	     $mode5=$mode5.replace("$url2$",$list1[i].url2); 
	  	     $('.model>.shop_tit').html($mode5)//改变标题里的内容
	  	     var $mode3=$('.model').html();
	  	     $mode3=$mode3.replace("$ss$",$list1[i].src1); //改变顶部图片的内容
	  	    $('.cl_cont_right').append($mode3)
	  	  
	  	    }
	  	       var $img1=$('.cl_cont_right .img1')
	  	     $.each($img1,function(i){
	  	     	if($($img1[i]).attr("src")==' '){
	  	     	  $(this).remove()
                console.log($($img1[i]).attr("src")==' ')
	  	     	}
	  	     })//删除无用的img1标签
	  	 }       
	  })

	
})
