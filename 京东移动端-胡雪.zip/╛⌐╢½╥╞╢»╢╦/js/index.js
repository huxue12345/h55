$(function(){
	$('.jd_footer').load('footer.html')
	var $width=$('.jd_banner').width();
	var $heigth=$('.jd_banner').height();
	var $li=$('.img>li').eq(0).clone(true);
	$('.img').append($li);
	$('.img').width($width*$('.img>li').length);
	$(window).resize(function(){
	var $width=$('.jd_banner').width();
	var $heigth=$('.jd_banner').height();
	var $li=$('.img>li').eq(0).clone(true);
	$('.img').append($li);
	$('.img').width($width*$('.img>li').length);
	});
	var startX=0;
	var lastX=0;
	var index=0;
	var $target=0;
	var time=null;
	var time1=null;
	time=setInterval(tab,2000);
	function slideleft(){
		if(index<$('.img>li').length-2){
		  index++;	
		}
		$('.btns>li').eq(index).addClass('now').siblings('li').removeClass('now')
		$target=-index*$width;
		$('.img').animate({'left':$target},500)
	}
	function slideright(){
		if(index>0){
		  index--;	
		}
		$('.btns>li').eq(index).addClass('now').siblings('li').removeClass('now')
		$target=-index*$width;
		$('.img').animate({'left':$target},500)
	}
	document.addEventListener('touchstart',function(ev){
		startX=ev.touches[0].pageX;
		clearInterval(time)
	})
	document.addEventListener('touchend',function(ev){
		lastX=ev.changedTouches[0].pageX;
		if(startX-lastX>200){
			slideleft()
		}
		else if(lastX-startX){
			slideright()
		}
		clearTimeout(time1)
		time1=setTimeout(function(){
		time=setInterval(tab,2000);	
		},3000)
	})
	function tab(){
		if(index==$('.img>li').length-1){
			index=0;
		$target=-index*$width;
		$('.img').animate({'left':$target}, 0)
		}
		index++;
		$target=-index*$width;
		$('.img').animate({'left':$target},500)
		if(index==$('.img>li').length-1){
		$('.btns>li').eq(0).addClass('now').siblings('li').removeClass('now')	
		}else{
		$('.btns>li').eq(index).addClass('now').siblings('li').removeClass('now')	
		}
	}
//轮播图
var $height=$('.wrap_move>li').eq(0).height();
setInterval(function(){
		$('.wrap_move').animate({"top":"-"+$height+"px"},1000,function(){
		$('.wrap_move').animate({"top":+0+"px"},0)
		$('.wrap_move>li').eq(0).appendTo($('.wrap_move'));	
		})
},2000)
//京东快报
//京东秒杀
$.ajax({
	"type":"get",
	"url":"json/ms.json",
	"data":{},
	"async":false,
	"dataType":'json'
}).done(function(str){
	console.log(str)
	var list=eval(str)
	$('.ms_move').html('')
	$.each(list,function(i){
	var mode=$('.model').html();
	mode=mode.replace('$src$',list[i].src)
	mode=mode.replace('$s01$',list[i].s01)
	mode=mode.replace('$s02$',list[i].s02)
	$('.ms_move').append(mode)
	})
});
var $widthli=$('.ms_move>li').eq(0).width();
var movewidth=$widthli*$('.ms_move>li').length;
$('.ms_move').width(movewidth);
var $widcont=$('.jd_ms_cont').width();
var $max=Math.round(movewidth/$widcont)
console.log($max)
console.log($('.ms_move>li').length,$widthli,movewidth)
var start1X=0,last1X=0;
var $num=0
$('.jd_ms_cont').on('touchstart',function(ev){
	start1X=ev.touches[0].pageX
	console.log(start1X)
	return ev.preventDefault()
})
$('.jd_ms_cont').on('touchend',function(ev){
	last1X=ev.changedTouches[0].pageX
	console.log(last1X);
	 if(start1X-last1X>0){
	 	
	 	if($num<$max-1){
	 	  $num++;
	 	}
	 	$('.ms_move').animate({'left':-$num*$widcont})
	 }else{
	 	if($num>0){
	 	  $num--;
	 	}
	 	$('.ms_move').animate({'left':-$num*$widcont})
	 }
	return ev.preventDefault()
})
function doboul(num){
	if(num<10){
		return "0"+num
	}else{
		return num
	}
}
var oDate =null;
var t1=null;
var onum=null;
var otim=null;
var t2=0;
var se=0;
var timc=0;
var ohou=0;
var omi=0 
function tim(){
oDate=new Date();//当前的日期
t1=oDate.getTime();
onum=oDate.getHours();
if(onum>22){
$('.shop').html("22点场")
 otim=oDate.setHours(24);
 otim=oDate.setMinutes(0);
 otim=oDate.setSeconds(0);
t2=otim;//设置秒杀的时间
timc=t2-t1;//时间差
se=parseInt(timc/1000);//秒数
ohou=parseInt(se/3600);//小时
    se=se%3600;
omi=parseInt(se/60)
 se=se%60;
   if(se<0){
    	$('.cotdow').html('秒杀结束')
   }
return 
}
if(onum>16){
 $('.shop').html("20点场")	
 otim=oDate.setHours(22);
 otim=oDate.setMinutes(0);
 otim=oDate.setSeconds(0);
t2=otim;//设置秒杀的时间
 timc=t2-t1;//时间差
se=parseInt(timc/1000);//秒数
ohou=parseInt(se/3600);//小时
    se=se%3600;
 omi=parseInt(se/60)//求分钟
    se=se%60;
 if(se<0){
    	$('.cotdow').html('秒杀结束')
   }
 return 
}
if(onum>10){
 $('.shop').html("16点场")
 otim=oDate.setHours(16);
 otim=oDate.setMinutes(0);
 otim=oDate.setSeconds(0);
t2=otim;//设置秒杀的时间
timc=t2-t1;//时间差
se=parseInt(timc/1000);//秒数
ohou=parseInt(se/3600);//小时
    se=se%3600;
omi=parseInt(se/60)
 se=se%60;
   if(se<0){
    	$('.cotdow').html('秒杀结束')
   }
    return 
}
 if(onum>=0){
 $('.shop').html("10点场")
 otim=oDate.setHours(10);
 otim=oDate.setMinutes(0);
 otim=oDate.setSeconds(0);
t2=otim;//设置秒杀的时间
timc=t2-t1;//时间差
se=parseInt(timc/1000);//秒数
ohou=parseInt(se/3600);//小时
    se=se%3600;
omi=parseInt(se/60)
 se=se%60
 console.log(se)
   if(se<0){
    	$('.cotdow').html('秒杀结束')
   }
    return 
}

console.log(oDate,t1,t2,timc,se,otim,ohou,omi,onum)
}

setInterval(function(){
tim()
$('.hour').html(doboul(ohou));
$('.minu').html(doboul(omi));
$('.sec').html(doboul(se));
},1000)
$(window).scroll(function(){
 if($(window).scrollTop()>0){
 	$('.jd_head').addClass('now')
 }
 else{
 	$('.jd_head').removeClass('now')
 }
})

})
