$(function(){
	function resize1(num){
	  var $width=$(window).width();
	  var $height=$(window).height();
	  $(num).width($width-160);
	  $(num).height($height);
	}
	resize1('.list_cont')
	function block(name,name1,name2){
	$(name).click(function(){
		$('.head').removeClass('now')
		$(name1).slideToggle(1000)
		$(this).toggleClass('now')
		$(name2).removeClass('now')
	})	
	}
	block('.op_mues','.op_mues_list','.op_mues2_list')
	block('.op_jiantou','.op_jiantou_list');
	function togg(num1,num2,num3){
		$(num1).click(function(){
			$(num2).toggleClass('now')
			$('.op_mues').removeClass('now')
			$('.op_mues_list').slideUp(30);
		})
	}
	togg('.head_font','.op_mues2_list',)
})
