$(function(){
 $('#banner_head').load('head.html');
 $('#footer').load('foot.html');
     console.log($('#banner_head .head'))
   var $newli=$('.li_01').clone(true)
   $('.play_cont').append($newli);
   var $ulwidth=$('.play_cont>li').length*$('.li_01').width()
   $('.play_cont').width($ulwidth);//设置图片的宽度
  var index=1
   function slideleft(){
   	console.log(1)
   	if(index>$('.play_cont>li').length-1){
   		index=0;
   		$('.play_cont').css('left',0)
   	}
    if(index==$('.play_cont>li').length-1){
   	$('.play_btn>li').eq(0).addClass('now').siblings('li').removeClass('now')	
   	}else{
   	$('.play_btn>li').eq(index).addClass('now').siblings('li').removeClass('now')		
   	}
   	if(index==3){
    $('.play_btn>li').css('background',"rgba(255,255,255,0.2)")	
    $('.play_btn .now').css('background',"rgba(255,255,255,0.4)")	
    }else{
    $('.play_btn>li').css('background',"rgba(0,0,0,0.2)")	
    $('.play_btn .now').css('background',"rgba(0,0,0,0.4)")	
    }
   	if($('.play_cont>li').eq(index).hasClass('li_03')||$('.play_cont>li').eq(index).hasClass('li_05')){
   			
   		$('#banner_head .head').removeClass('now')
   		
   	}else{
   	   $('#banner_head .head').addClass('now')
   	}//导航颜色的变化
   	if(index<=0){
   	//index等于0时，避免字体移动两次	
   	}else{
   	$('.play_cont>li').eq(index).find('.li_tit').addClass('now')
   	$('.play_cont>li').eq(index).siblings('li').find('.li_tit').removeClass('now now1')	
   	}
    $('.play_cont').stop().animate({"left":-index*$('.li_01').width()},400)
   
    index++
   }
     clearInterval(time)
    var time=setInterval(slideright,2000)
    function slideright(){
    	index--	
    	if(index<0){
    		index=$('.play_cont>li').length-1
           $('.play_cont').css('left',-index*$('.li_01').width())
        } 
        $('.play_cont').stop().animate({"left":-index*$('.li_01').width()},400)
        $('.play_btn>li').eq(index).addClass('now').siblings('li').removeClass('now')
      if(index<=0||index==$('.play_cont>li').length-1){
   	//index等于0时，避免字体移动两次	
      	}else{
     	$('.play_cont>li').eq(index).find('.li_tit').addClass('now1')
     	$('.play_cont>li').eq(index).siblings('li').find('.li_tit').removeClass('now now1')	
     	}	
        	if(index==3){
          $('.play_btn>li').css('background',"rgba(255,255,255,0.2)")	
          $('.play_btn .now').css('background',"rgba(255,255,255,0.4)")	
          }else{
           $('.play_btn>li').css('background',"rgba(0,0,0,0.2)")	
           $('.play_btn .now').css('background',"rgba(0,0,0,0.4)")	
       }
        if($('.play_cont>li').eq(index).hasClass('li_03')||$('.play_cont>li').eq(index).hasClass('li_05')){
   		 $('#banner_head .head').removeClass('now') 
   		 
     	}else{
   		$('#banner_head .head').addClass('now') 
   		
     	}
    }
    var startX=0;
    var time1=null
    $('.tabplay').on("touchstart",function(ev){
//  	ev.preventDefault();
    	startX=ev.touches[0].pageX;
    	clearInterval(time)
    })
    $('.tabplay').on("touchend",function(ev){
//  	ev.preventDefault();
    	var lastX=ev.changedTouches[0].pageX;
    	if(startX-lastX>0){//左滑
    	slideleft()
    	clearTimeout(time1)
       time1=setTimeout(function(){
    	time=setInterval(slideleft,2000)	
    	},3000)
    	}
    	else{
    	slideright()	
    	}
    	clearTimeout(time1)
        time1=setTimeout(function(){
    	time=setInterval(slideright,2000)	
    	},3000)
    })
 $('.play_cont>li').on('click',function(){
		var $artcid=$(this).attr('date-art');
		console.log($artcid)
	    window.open('product.html?news=date0'+$artcid)
	})
   
   
})
