	$(function(){
	 $('#banner_head').load('head.html');
	 function cc(){
	 	 $('#banner_head .head').removeClass('now')
	 	 console.log($('#banner_head .head'))
	 }
	 	 var $num=getURL('news')
	 	 var list=prolist[$num]
	 	 console.log($num,prolist,list)
	 	$('.tit').html(list.tit);
		$('.p_01').html(list.p01);
		$('.a01').html(list.a01);
		$('.p_price').html(list.price);
		$('.img_kuang img').attr('src',list.src);
		$('.p_02 span').html(list.p02);
		$('.a02').html(list.a02);
		$('.a03').html(list.a03);
	 	 
	 function getURL(names){
			var reg=new RegExp('(^|&)'+names+'=([^&]*)(&|$)')
			var r=window.location.search.substr(1).match(reg);
			if(r!=null){
				console.log(r[2])
				return r[2];
			}else{
				return '';
			}
		}
 })
 