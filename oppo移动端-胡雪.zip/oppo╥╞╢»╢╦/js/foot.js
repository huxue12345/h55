$(function(){
  function Dislist(name){
  	$(name).click(function(){
  		$(this).toggleClass('now');
  		$(this).parent().next().slideToggle(500)
  	})
  }
   Dislist('.add')
})
