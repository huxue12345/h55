$(function(){
	$('#banner_head').load('head.html')
	$('#footer').load('foot.html');
   var $newli=$('.play_cont .li_01').clone(true)
   $('.play_cont').append($newli);
   var $ulwidth=$('.play_cont>li').length*$('.li_01').width()
   $('.play_cont').width($ulwidth);//设置图片的宽度
   var index=1
   console.log($('.play_cont>li').length)
   function slideleft(){
   	console.log(1)
   	if(index>$('.play_cont>li').length-1){
   		index=0;
   		$('.play_cont').css('left',0)
   	}
    if(index==$('.play_cont>li').length-1){
   	$('.play_btn>li').eq(0).addClass('now').siblings('li').removeClass('now')	
   	}else{
   	$('.play_btn>li').eq(index).addClass('now').siblings('li').removeClass('now')		
   	}
   	if(index==5){
    $('.play_btn>li').css('background',"rgba(255,255,255,0.2)")	
    $('.play_btn .now').css('background',"rgba(255,255,255,0.4)")	
    }else{
    $('.play_btn>li').css('background',"rgba(0,0,0,0.2)")	
    $('.play_btn .now').css('background',"rgba(0,0,0,0.4)")	
    }
   	if($('.play_cont>li').eq(index).hasClass('li_04')||$('.play_cont>li').eq(index).hasClass('li_05')||$('.play_cont>li').eq(index).hasClass('li_07')){
   		$('#banner_head .head').removeClass('now')
   	}else{
   		$('#banner_head .head').addClass('now')
   	}//导航颜色的变化
   	if(index==0){
   	//index等于0时，避免字体移动两次	
   	}else{
   	$('.play_cont>li').eq(index).find('.li_tit').addClass('now')
   	$('.play_cont>li').eq(index).siblings('li').find('.li_tit').removeClass('now now1')	
   	}
    $('.play_cont').stop().animate({"left":-index*$('.li_01').width()},400)
   
    index++
   }
     clearInterval(time)
    var time=setInterval(slideleft,2000)
    function slideright(){
    	index--	
    	if(index<0){
    		index=$('.play_cont>li').length-1
           $('.play_cont').css('left',-index*$('.li_01').width())
        } 
        $('.play_cont').stop().animate({"left":-index*$('.li_01').width()},400)
        $('.play_btn>li').eq(index).addClass('now').siblings('li').removeClass('now')
      if(index<0||index==$('.play_cont>li').length-1){
   	//index等于0时，避免字体移动两次	
      	}else{
     	$('.play_cont>li').eq(index).find('.li_tit').addClass('now1')
     	$('.play_cont>li').eq(index).siblings('li').find('.li_tit').removeClass('now now1')	
     	}	
        	if(index==5){
          $('.play_btn>li').css('background',"rgba(255,255,255,0.2)")	
          $('.play_btn .now').css('background',"rgba(255,255,255,0.4)")	
          }else{
           $('.play_btn>li').css('background',"rgba(0,0,0,0.2)")	
           $('.play_btn .now').css('background',"rgba(0,0,0,0.4)")	
       }
        if($('.play_cont>li').eq(index).hasClass('li_04')||$('.play_cont>li').eq(index).hasClass('li_05')||$('.play_cont>li').eq(index).hasClass('li_07')){
   		   $('#banner_head .head').removeClass('now')
     	}else{
   		$('#banner_head .head').addClass('now')
     	}
    }
    var startX=0;
    var time1=null
    $('.tabplay').on("touchstart",function(ev){
    	ev.preventDefault();
    	startX=ev.touches[0].pageX;
    	clearInterval(time)
    })
    $('.tabplay').on("touchend",function(ev){
    	ev.preventDefault();
    	var lastX=ev.changedTouches[0].pageX;
    	if(startX-lastX>0){//左滑
    	slideleft()
    	clearTimeout(time1)
       time1=setTimeout(function(){
    	time=setInterval(slideleft,2000)	
    	},3000)
    	}
    	else{
    	slideright()	
    	}
    	clearTimeout(time1)
       time1=setTimeout(function(){
    	time=setInterval(slideright,2000)	
    	},3000)
    })
        function width1(name1,name2){
     	var $width=$(name1).eq(0).innerWidth();
     	var $ulwidth=$width*$(name1).length
     	   $(name2).width($ulwidth);
     	   console.log($width,$ulwidth)
     }
   width1('.up_tab .tab_cont_wrap>li','.up_tab .tab_cont_wrap')
   width1('.down_tap .tab_cont_wrap>li','.down_tap .tab_cont_wrap')
     var list1=eval(list)
      var index1=0;
     function left(name1){
     	var num=$(name1).attr('date-num')
     	console.log(num)
     	var list2=list1['date0'+num];
     	if(index1<$('.up_tab .tab_cont_wrap>li').length-1){
     		index1++
     	}
     	if(index1>$('.up_tab .tab_cont_wrap>li').length-1){
     		index1=$('.up_tab .tab_cont_wrap>li').length-1
     	}
     	if(index1==2){
     		$('.s_tab ').css("background","#55bfbc")
     	}else{
     		$('.s_tab ').css("background","#1a3ed8")
     	}
     	$(name1+' .btn>li').eq(index1).addClass('now').siblings('li').removeClass('now');
         $(name1+' .tab_cont_wrap').stop().animate({'left':-750*index1})
        $(name1+' .tab_cont_wrap>li').eq(index1).find("img").addClass('now');
        
         $(name1+' .tab_cont_wrap>li').eq(index1).siblings('li').find("img").removeClass('now')
        
        $(name1+' .lit_tit').html(list2[index1].tit);
        $(name1+' .tit_des').html(list2[index1].price);
        $(name1+' .s_tab_price').html(list2[index1].des);
     }
      function right(name1){
     	var num=$(name1).attr('date-num')
     	console.log(num)
     	var list2=list1['date0'+num];
     	if(index1>0){
     		index1--
     	}
     	if(index1<0){
     		index1=0
     	}
     	if(index1==2){
     		$('.s_tab ').css("background","#55bfbc")
     	}else{
     		$('.s_tab ').css("background","#1a3ed8")
     	}
     	$(name1+' .btn>li').eq(index1).addClass('now').siblings('li').removeClass('now');
        $(name1+' .tab_cont_wrap').stop().animate({'left':-750*index1})
        $(name1+' .tab_cont_wrap>li').eq(index1).find("img").addClass('now');
        
         $(name1+' .tab_cont_wrap>li').eq(index1).siblings('li').find("img").removeClass('now')
        
        $(name1+' .lit_tit').html(list2[index1].tit);
        $(name1+' .tit_des').html(list2[index1].price);
        $(name1+' .s_tab_price').html(list2[index1].des);
     }
     
     
     var start1X=0
    $('.up_tab').on('touchstart',function(ev){
    	ev.preventDefault()
    	start1X=ev.touches[0].pageX
    })
    $('.up_tab').on('touchend',function(ev){
    	var last1X=ev.changedTouches[0].pageX
         if(start1X-last1X>0){
         	left(".up_tab")
         }
         else{
            right(".up_tab")
         }
    }) 
    var start2X=0
      $('.down_tap').on('touchstart',function(ev){
    	ev.preventDefault()
    	start2X=ev.touches[0].pageX
    })
    $('.down_tap').on('touchend',function(ev){
    	var last1X=ev.changedTouches[0].pageX
         if(start1X-last1X>0){
         	left(".down_tap")
         }
         else{
            right(".down_tap")
         }
    })
    var litstartx=0
    $('.s_cont_tit').on('touchstart',function(ev){
    	litstartx=ev.touches[0].pageX;
    	console.log(1,litstartx)
    })
    $('.s_cont_tit').on('touchend',function(ev){
    	var litlastx=ev.changedTouches[0].pageX;
    	console.log(2,litlastx)
    	if(litstartx-litlastx>0){
    	$('.tit_cont').css('left','-0.3rem')	
    	}else{
    	$('.tit_cont').css('left','0rem')		
    	}
    })
   var $top=$('.s_cont').css('top')
   $(window).scroll(function(){
   	console.log($('html,body').scrollTop())
   	 if($('html,body').scrollTop()>3255){
   	 	$('.s_cont .s_cont_tit').css({'position':'fixed',
   	 	'top':"0rem",'left':'0rem',"height":"2rem"})
   	 	$('.cont_01').css('marginTop',"2rem")
   	 }else{
   	 $('.s_cont .s_cont_tit').css({'position':'relative',
   	 	'top':"0rem",'left':'0rem', "height":"2.07rem"})
   	 $('.cont_01').css('marginTop',"0rem")
   	 }
   })
})
